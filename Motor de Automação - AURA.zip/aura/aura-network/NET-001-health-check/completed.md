# AURA-NET-001 - Health Check

## Capability Completion Document v1.0

---

# 1. Informações Gerais

| Campo              | Valor                             |
| ------------------ | --------------------------------- |
| Capability ID      | AURA-NET-001                      |
| Nome               | Health Check                      |
| Motor              | AURA Network                      |
| Domínio            | Network                           |
| Vendor Inicial     | Cisco                             |
| Tecnologia Inicial | Cisco ACI                         |
| Versão             | 1.0                               |
| Status             | MVP                               |
| Tipo               | Read Only                         |
| Executor           | Ansible Automation Platform (AAP) |

---

# 2. Objetivo

O capability AURA-NET-001 tem como objetivo realizar uma avaliação padronizada da saúde operacional de ambientes de rede suportados pelo AURA.

Esta capability estabelece a fundação arquitetural da plataforma AURA, definindo o padrão de coleta, normalização, avaliação e geração de resultados reutilizáveis para futuros vendors e tecnologias.

---

# 3. Escopo Inicial

Tecnologia suportada:

* Cisco ACI

Escopo funcional:

* Coleta de saúde geral do fabric
* Coleta de faults
* Coleta de nós do fabric
* Coleta do cluster APIC
* Normalização dos dados
* Avaliação de saúde
* Geração de relatório padronizado

---

# 4. Estrutura do Capability

```text
NET-001-health-check/

├── spec.md
├── completed.md
├── playbook.yml
├── vars.yml
│
├── collectors/
│   ├── collect_fabric_health.yml
│   ├── collect_faults.yml
│   ├── collect_nodes.yml
│   └── collect_cluster.yml
│
├── parsers/
│   └── normalize_health.yml
│
├── rules/
│   └── evaluate_health.yml
│
├── report/
│   └── generate_report.yml
│
└── schemas/
    └── health_check_schema.json
```

---

# 5. Entrada

## Arquivo

vars.yml

## Estrutura

```yaml
aura_target:

  vendor: cisco
  technology: aci

  host: x.x.x.x
  username: usuario
  password: senha

  validate_certs: false
```

---

# 6. Collectors

## 6.1 Fabric Health

Objetivo:

Coletar o health score geral do fabric.

Dados coletados:

* Health Average

---

## 6.2 Fault Summary

Objetivo:

Coletar faults presentes no ambiente.

Dados coletados:

* Critical Faults
* Major Faults
* Minor Faults
* Warning Faults

---

## 6.3 Fabric Nodes

Objetivo:

Inventariar nós do fabric.

Dados coletados:

* Controllers
* Leafs
* Spines
* Status dos nós

---

## 6.4 Cluster Status

Objetivo:

Coletar informações do cluster APIC.

Dados coletados:

* Cluster State
* Controllers
* Status Operacional

---

# 7. Parser

Arquivo:

```text
parsers/normalize_health.yml
```

Responsável por converter informações específicas do Cisco ACI para o modelo de dados padronizado do AURA.

Exemplo:

Entrada:

```json
{
  "healthAvg": "95"
}
```

Saída:

```json
{
  "health_score": 95
}
```

---

# 8. Rules Engine

Arquivo:

```text
rules/evaluate_health.yml
```

Regras implementadas:

| Regra              | Resultado |
| ------------------ | --------- |
| Critical Fault > 0 | Critical  |
| Health Score < 80  | Warning   |
| Caso contrário     | Healthy   |

---

# 9. Modelo de Saída

Arquivo:

```text
report/generate_report.yml
```

Estrutura:

```json
{
  "capability": "NET-001",
  "motor": "network",
  "vendor": "cisco",
  "technology": "aci",
  "status": "healthy",
  "score": 95,
  "critical_faults": 0,
  "major_faults": 2,
  "recommendations": []
}
```

---

# 10. Schema

Arquivo:

```text
schemas/health_check_schema.json
```

Objetivo:

Padronizar a saída do capability para utilização futura por:

* Dashboards
* Catálogo AURA
* APIs
* ServiceNow
* GraphRAG
* Agentes
* Analytics

---

# 11. Fluxo de Execução

```text
Usuário
    ↓
AURA Core
    ↓
AURA Network
    ↓
NET-001
    ↓
Collectors
    ↓
Cisco ACI
    ↓
Parser
    ↓
Rules Engine
    ↓
Report
    ↓
JSON AURA
```

---

# 12. Critérios de Aceite

## CA-01

Conectar com sucesso ao Cisco APIC.

---

## CA-02

Executar todos os collectors.

---

## CA-03

Normalizar os dados coletados.

---

## CA-04

Aplicar regras de avaliação.

---

## CA-05

Gerar saída padronizada do AURA.

---

## CA-06

Executar localmente e via AAP.

---

# 13. Evolução Prevista

Versão 1.0

* Cisco ACI
* Health Check Básico

Versão 2.0

* Juniper
* Arista

Versão 3.0

* Recommendation Engine

Versão 4.0

* Agent Integration

Versão 5.0

* Autonomous Operations

---

# 14. Status Final

| Item         | Status         |
| ------------ | -------------- |
| Foundation   | Concluído      |
| Architecture | Concluído      |
| Collectors   | Concluído      |
| Parser       | Concluído      |
| Rules        | Concluído      |
| Report       | Concluído      |
| Schema       | Concluído      |
| Capability   | MVP Finalizado |

---

## Resultado

O AURA-NET-001 estabelece o primeiro capability oficial da plataforma AURA e define o padrão arquitetural que será reutilizado pelos demais motores e capabilities da plataforma.
