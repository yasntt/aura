# AURA-NET-001 Specification

## Health Check Capability

---

# 1. Informações Gerais

| Campo              | Valor        |
| ------------------ | ------------ |
| Capability ID      | NET-001      |
| Nome               | Health Check |
| Motor              | AURA Network |
| Vendor Inicial     | Cisco        |
| Tecnologia Inicial | ACI          |
| Versão             | 1.0          |
| Status             | MVP          |

---

# 2. Objetivo

Executar uma avaliação padronizada da saúde operacional de ambientes de rede suportados pelo AURA.

Esta capability deverá coletar informações operacionais, normalizar os dados obtidos, aplicar regras de avaliação e produzir um resultado padronizado independente do fabricante.

---

# 3. Escopo Inicial

Tecnologia suportada:

* Cisco ACI

Indicadores avaliados:

* Fabric Health
* Faults
* Fabric Nodes
* APIC Cluster

---

# 4. Entradas

Arquivo:

```text
vars.yml
```

Estrutura:

```yaml
aura_target:

  vendor: cisco
  technology: aci

  host: x.x.x.x
  username: usuario
  password: senha

  validate_certs: false
```

---

# 5. Collectors

## collect_fabric_health.yml

Objetivo:

Coletar health score do fabric.

---

## collect_faults.yml

Objetivo:

Coletar faults críticos, major e minor.

---

## collect_nodes.yml

Objetivo:

Coletar leafs, spines e controllers.

---

## collect_cluster.yml

Objetivo:

Coletar estado do cluster APIC.

---

# 6. Parser

Arquivo:

```text
parsers/normalize_health.yml
```

Responsabilidades:

* Converter dados Cisco para modelo AURA.
* Padronizar nomenclaturas.
* Consolidar indicadores.

---

# 7. Rules Engine

Arquivo:

```text
rules/evaluate_health.yml
```

Regras:

| Condição           | Resultado |
| ------------------ | --------- |
| Critical Fault > 0 | Critical  |
| Health Score < 80  | Warning   |
| Caso contrário     | Healthy   |

---

# 8. Output Esperado

Formato:

```json
{
  "capability":"NET-001",
  "motor":"network",
  "vendor":"cisco",
  "technology":"aci",
  "status":"healthy",
  "score":95,
  "critical_faults":0,
  "major_faults":2,
  "recommendations":[]
}
```

---

# 9. Critérios de Aceite

* Conectar ao APIC.
* Executar collectors.
* Normalizar dados.
* Avaliar regras.
* Gerar relatório.
* Produzir saída padronizada.

---

# 10. Evolução Prevista

v1.0

* Cisco ACI

v2.0

* Juniper

v3.0

* Arista

v4.0

* Recommendation Engine

v5.0

* Agent Integration
