# AURA-NET-002 Specification

## Compliance Capability

---

# 1. Informações Gerais

| Campo              | Valor                             |
| ------------------ | --------------------------------- |
| Capability ID      | NET-002                           |
| Nome               | Compliance                        |
| Motor              | AURA Network                      |
| Domínio            | Network                           |
| Vendor Inicial     | Cisco                             |
| Tecnologia Inicial | Cisco ACI                         |
| Versão             | 1.0                               |
| Status             | MVP                               |
| Tipo               | Read Only                         |
| Executor           | Ansible Automation Platform (AAP) |

---

# 2. Objetivo

O capability AURA-NET-002 tem como objetivo validar a aderência dos ambientes de rede aos padrões operacionais definidos pelo AURA.

Esta capability executa auditorias automatizadas, identifica desvios de configuração, classifica a severidade dos achados e recomenda ações operacionais padronizadas.

---

# 3. Escopo Inicial

Tecnologia suportada:

* Cisco ACI

Escopo funcional:

* Auditoria de VPC Policy Groups
* Auditoria de Port Channel Policy Groups
* Auditoria de Access Port Groups
* Validação de padrões operacionais
* Classificação de severidade
* Recomendação de ações
* Geração de relatório padronizado

---

# 4. Estrutura do Capability

```text
NET-002-compliance/

├── spec.md
├── completed.md
├── playbook.yml
├── vars.yml
│
├── collectors/
│   ├── collect_vpc.yml
│   ├── collect_pc.yml
│   └── collect_acc.yml
│
├── parsers/
│   └── normalize_compliance.yml
│
├── rules/
│   ├── validate_vpc.yml
│   ├── validate_pc.yml
│   ├── validate_acc.yml
│   └── classify_severity.yml
│
├── report/
│   └── generate_report.yml
│
└── schemas/
    └── compliance_schema.json
```

---

# 5. Entrada

Arquivo:

```text
vars.yml
```

Estrutura:

```yaml
aura_target:

  vendor: cisco
  technology: aci

  host: x.x.x.x
  username: usuario
  password: senha

  validate_certs: false


aura_compliance:

  policies:

    mcp: ON

    cdp: OFF

    lldp: ON

    link_level: AUTO

    stp:

      - STP_BPDU_GUARD
      - STP_BPDU_PASS
```

---

# 6. Collectors

## 6.1 collect_vpc.yml

Objetivo:

Coletar todos os VPC Policy Groups configurados no Cisco ACI.

Dados coletados:

* Nome
* CDP
* LLDP
* MCP
* STP
* Link Level

---

## 6.2 collect_pc.yml

Objetivo:

Coletar todos os Port Channel Policy Groups.

Dados coletados:

* Nome
* CDP
* LLDP
* MCP
* STP
* Link Level

---

## 6.3 collect_acc.yml

Objetivo:

Coletar todos os Access Port Policy Groups.

Dados coletados:

* Nome
* CDP
* LLDP
* MCP
* STP
* Link Level

---

# 7. Parser

Arquivo:

```text
parsers/normalize_compliance.yml
```

Objetivo:

Converter objetos específicos do Cisco ACI para o modelo padronizado do AURA.

Exemplo:

Entrada:

```json
{
  "infraAccBndlGrp": {
    "attributes": {
      "name": "VPC_CORE_ETH1"
    }
  }
}
```

Saída:

```json
{
  "name": "VPC_CORE_ETH1",
  "type": "VPC",
  "mcp": "ON",
  "cdp": "OFF",
  "lldp": "ON"
}
```

---

# 8. Regras de Compliance

## MCP

| Condição  | Resultado |
| --------- | --------- |
| MCP != ON | MCP_OFF   |

---

## CDP

| Condição   | Resultado |
| ---------- | --------- |
| CDP != OFF | CDP_ON    |

---

## LLDP

| Condição   | Resultado |
| ---------- | --------- |
| LLDP != ON | LLDP_OFF  |

---

## STP

| Condição                     | Resultado     |
| ---------------------------- | ------------- |
| Política diferente do padrão | STP_INCORRETO |

---

## Link Level

| Condição          | Resultado            |
| ----------------- | -------------------- |
| Diferente de AUTO | LINK_LEVEL_INCORRETO |

---

## Naming Convention

| Condição            | Resultado      |
| ------------------- | -------------- |
| Nome fora do padrão | NOME_INCORRETO |

---

# 9. Classificação

| Regra                | Severidade |
| -------------------- | ---------- |
| MCP_OFF              | CRITICAL   |
| CDP_ON               | HIGH       |
| LLDP_OFF             | HIGH       |
| STP_INCORRETO        | HIGH       |
| LINK_LEVEL_INCORRETO | MEDIUM     |
| NOME_INCORRETO       | MEDIUM     |

---

# 10. Ações Recomendadas

| Regra                | Ação                    |
| -------------------- | ----------------------- |
| MCP_OFF              | SELF_HEALING_AUTOMATICO |
| STP_INCORRETO        | CRIAR_TICKET_MESA       |
| CDP_ON               | CRIAR_TICKET_MESA       |
| LLDP_OFF             | ANALISE_N3              |
| LINK_LEVEL_INCORRETO | ANALISE_N3              |
| NOME_INCORRETO       | ANALISE_N3              |

---

# 11. Modelo de Saída

Arquivo:

```text
report/generate_report.yml
```

Estrutura:

```json
{
  "capability": "NET-002",
  "motor": "network",
  "vendor": "cisco",
  "technology": "aci",
  "compliance_score": 94,
  "critical": 1,
  "high": 2,
  "medium": 3,
  "findings": [
    {
      "name": "VPC_CORE_ETH1",
      "type": "VPC",
      "issue": "MCP_OFF",
      "severity": "CRITICAL",
      "recommended_action": "SELF_HEALING_AUTOMATICO"
    }
  ]
}
```

---

# 12. Schema

Arquivo:

```text
schemas/compliance_schema.json
```

Objetivo:

Padronizar a saída do capability para consumo por:

* Portal AURA
* Dashboard
* ServiceNow
* APIs
* Analytics
* GraphRAG
* Agentes
* Recommendation Engine

---

# 13. Fluxo de Execução

```text
Usuário
    ↓
AURA Core
    ↓
AURA Network
    ↓
NET-002
    ↓
Collectors
    ↓
Cisco ACI
    ↓
Parser
    ↓
Rules Engine
    ↓
Classification
    ↓
Recommendations
    ↓
AURA Report
```

---

# 14. Critérios de Aceite

## CA-01

Conectar ao Cisco APIC.

---

## CA-02

Executar coleta dos grupos VPC.

---

## CA-03

Executar coleta dos grupos PC.

---

## CA-04

Executar coleta dos grupos ACC.

---

## CA-05

Executar validações de compliance.

---

## CA-06

Classificar severidades.

---

## CA-07

Gerar recomendações.

---

## CA-08

Produzir relatório padronizado do AURA.

---

# 15. Evolução Prevista

Versão 1.0

* Cisco ACI

Versão 2.0

* Compliance Templates
* Policy Baselines

Versão 3.0

* Self Healing Engine

Versão 4.0

* Recommendation Engine

Versão 5.0

* Agent Integration

---

# 16. Status Esperado

| Item           | Status             |
| -------------- | ------------------ |
| Foundation     | Concluído          |
| Architecture   | Concluído          |
| Collectors     | Planejado          |
| Parser         | Planejado          |
| Rules          | Planejado          |
| Classification | Planejado          |
| Report         | Planejado          |
| Capability     | Em Desenvolvimento |

---

## Resultado Esperado

O AURA-NET-002 estabelecerá o primeiro mecanismo de Compliance e Decision Engine do AURA, servindo como base para futuras capabilities de Self Healing, Recommendation Engine e Autonomous Operations.
